<template>
    <div class="home">
      <h1>首页</h1>
      <p>欢迎来到Vue3示例项目</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'HomeView'
  }
  </script> 