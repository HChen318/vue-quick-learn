<template>
  <div class="page">
    <h4>页面 3</h4>
    <p>这是通过编程式导航访问的页面</p>
  </div>
</template> 