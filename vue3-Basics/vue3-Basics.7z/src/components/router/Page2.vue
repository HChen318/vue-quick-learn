<template>
  <div class="page">
    <h4>页面 2</h4>
    <p>这是路由演示的第二个页面</p>
  </div>
</template> 