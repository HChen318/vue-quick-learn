<template>
  <div class="router-page">
    <h3>路由页面1</h3>
    <p>这是一个基本的路由页面</p>
  </div>
</template>

<script>
export default {
  name: 'RouterPage1'
}
</script> 