<template>
  <div class="router-page">
    <h3>路由页面2</h3>
    <p>这是通过命名路由访问的页面</p>
  </div>
</template>

<script>
export default {
  name: 'RouterPage2'
}
</script> 